# MIDOC — TODO.md
Última actualización: Agosto 2026

Prioridad ordenada por impacto en el objetivo #1 del negocio: **conseguir médicos piloto pagando** (ver CONTEXT.md sección 4 — gap crítico actual: cero MRR real).

---

## 🔴 P0 — Bloqueantes para onboardear médicos piloto

- [ ] **Contratar e integrar PAC (timbrado CFDI)** — Facturapi o SW Sapien. Sin esto no se puede facturar, y facturación es uno de los 10 módulos core.
- [ ] **Activar WhatsApp Business API** — Twilio o 360dialog. Las 4 plantillas de mensaje (confirmación de cita, recordatorio 24h, receta lista, confirmación de pago) ya están redactadas en categoría "utility" y listas para someter a aprobación de Meta. Falta: elegir proveedor, contratar, someter plantillas, integrar.
- [ ] **QA end-to-end de los 10 módulos en producción** — antes de meter al primer médico piloto real.

## 🟠 P1 — Infraestructura / observabilidad

- [ ] **Instalar Sentry** (monitoreo de errores) — bloqueado anteriormente por PATH de Node.js en Windows; reintentar usando CMD (no PowerShell), ver CONTEXT.md sección 5.
- [ ] **Instalar Upstash Redis** (rate limiting / caching) — mismo bloqueador histórico que Sentry.

## 🟡 P2 — Onboarding de médicos piloto

- [ ] Reclutar 3–5 médicos piloto vía red personal (familiares/amigos médicos en Mexicali). Táctica validada: pedir demo de 15 minutos, **no** venta directa.
- [ ] Producir plantilla estándar de importación CSV para migración de expedientes.
- [ ] Producir checklist de onboarding.
- [ ] Ejecutar plan de onboarding en dos fases: (1) 3–5 médicos, alto contacto/manual → (2) escalar a 100–120 con modelo semi-autoservicio.
- [ ] **Nota:** la migración de expedientes es el cuello de botella operativo identificado como principal — priorizar tooling que la agilice.

## 🟢 P3 — UX (score actual: 72/100)

- [ ] Tour guiado dentro de la app (in-app tour)
- [ ] Diseñar empty states
- [ ] Humanizar mensajes de error (reemplazar errores técnicos crudos por lenguaje claro para médicos no técnicos)

## 🔵 P4 — Producto / estrategia a mediano plazo

- [ ] Evaluar construir compatibilidad de importación con Noa Notes (Doctoralia) — convertir su feature en un canal de adquisición para MIDOC en vez de competir directo en generación de notas.

## ⚪ P5 — Fundraising (no es tarea técnica directa, pero impacta prioridades)

- [ ] Insertar slide de equipo en `MIDOC_Investor_Deck.pptx` (bios y credenciales del founder ya redactadas, falta insertarlas en el PPTX real) — requisito antes de acercarse a Dalus Capital.
- [ ] Una vez haya médicos pagando: actualizar el deck de inversionistas con MRR real en vez de solo proyecciones.
- [ ] Orden de contacto a inversionistas: Blue Zone Ventures y ArkFund primero (no requieren team slide) → Dalus Capital después (sí requiere team slide) → Balero/Carabela → 99 Startups/Angel Hub.

---

## Ya resuelto (no repetir / no re-investigar)

- ✅ Despliegue en Vercel funcionando (`midoc-app.vercel.app`)
- ✅ PATH de Node.js en CMD (usar CMD, no PowerShell)
- ✅ Conflictos de peer dependencies npm (`--legacy-peer-deps`)
- ✅ Reactivación de Supabase
- ✅ Variables de entorno corregidas en Vercel (recordar: no se auto-populan desde `.env` local)
- ✅ Patrón de Supabase admin client definido (usar `createClient` directo)
- ✅ 4 plantillas de mensaje de WhatsApp redactadas (falta someter/aprobar, no redactar)
