# MIDOC — CONTEXT.md
**Documento de contexto técnico y arquitectura**
Última actualización: Agosto 2026
Autor: Jose Manuel (founder solo)

---

## 1. Qué es MIDOC

MIDOC es un SaaS de HealthTech para médicos de práctica privada en México. Cubre el ciclo clínico completo — no solo la generación de notas — sino que **cierra el ciclo**: de la nota clínica a la receta firmada, a la factura, al seguimiento automatizado.

**Posicionamiento estratégico (frase clave para cualquier decisión de producto):**
> "Doctoralia te ayuda a escribir la nota; MIDOC convierte esa nota en una receta firmada, una factura y un seguimiento automatizado — sin copiar y pegar nada."

MIDOC no compite en generación de notas (ahí Doctoralia con Noa Notes ya juega). MIDOC compite en **cierre del flujo post-nota**: Noa Notes genera la nota pero el médico tiene que copiarla manualmente a otro lado — ahí es donde MIDOC se diferencia con automatización completa.

---

## 2. Stack tecnológico

| Componente | Tecnología |
|---|---|
| Frontend web | Next.js 14 |
| Backend / DB / Auth | Supabase (proyecto: `msjxipjhoioynmlsjdhz.supabase.co`) |
| App móvil (paciente) | Expo React Native |
| IA (consultas, asistencia) | Claude API (Anthropic) |
| Hosting / deploy | Vercel — `midoc-app.vercel.app` |
| Facturación CFDI (pendiente de contratar) | Facturapi o SW Sapien (PAC) |
| WhatsApp Business API (pendiente) | Twilio (~$49 USD/mes + markup) o 360dialog (~$60 USD/mes) |
| Monitoreo de errores (pendiente) | Sentry |
| Cache / rate limiting (pendiente) | Upstash Redis |

---

## 3. Módulos en producción (10)

El sistema cubre el flujo clínico completo con cumplimiento regulatorio mexicano:

1. Expediente clínico conforme a **NOM-004** (norma oficial mexicana de expediente clínico)
2. Recetas digitales con firma electrónica
3. Facturación CFDI (integración PAC pendiente)
4. Videoconsultas con IA
5. Automatización por WhatsApp
6. Agenda / programación de citas
7. App de paciente (Expo React Native)
8. (+3 módulos adicionales del flujo clínico ya en producción — confirmar con el founder el detalle exacto de cada uno al onboardear)

**Nota para el nuevo programador:** el despliegue está vivo en Vercel y los bloqueadores históricos de despliegue ya están resueltos (ver sección 6).

---

## 4. Modelo de negocio (contexto de producto, relevante para priorización técnica)

- **Precio:** $2,499 MXN/mes (Founders Club, precio congelado de por vida) vs. $3,999 MXN/mes (precio regular)
- **Punto de equilibrio:** 8 médicos pagando
- **Meta año 1:** 150 médicos (100 a precio fundador, 50 a precio regular)
- **CAC objetivo:** $10,000–$15,000 MXN por médico
- **LTV base:** $59,976 MXN (retención de 24 meses a precio fundador)
- **Estado actual: CERO médicos pagando confirmados.** Este es el gap crítico del negocio — no solo de producto. Cualquier fricción técnica que retrase el onboarding de los primeros 3–5 médicos piloto tiene impacto directo en la ronda de inversión.

---

## 5. Decisiones de arquitectura clave

- **Supabase admin client:** usar llamadas directas a `createClient`, **no** el patrón de import `createSupabaseAdmin` — este último causó imports rotos en producción.
- **Next.js en Vercel:** el Framework Preset en Vercel Dashboard → Settings → Build and Development Settings debe estar en **"Next.js"**, no en "Other". Configurarlo mal ha causado errores de build en el pasado.
- **Variables de entorno en Vercel:** no se auto-populan desde `.env` local — hay que corregirlas manualmente en el Dashboard. El error `"Invalid supabaseUrl"` en producción casi siempre es un valor placeholder en las env vars de Vercel, no un bug de código.
- **Entorno de desarrollo (Windows):** usar siempre **CMD** (Windows+R → cmd), **nunca PowerShell** — PowerShell rompe consistentemente el PATH de Node.js/npm. Navegar con ruta relativa `cd OneDrive\Documents\MIDOC` antes de cualquier comando npm o Vercel.
- **Conflictos de dependencias npm:** resolver con la bandera `--legacy-peer-deps`.
- **Cumplimiento regulatorio:** todo el módulo de expediente clínico debe respetar NOM-004 — esto no es opcional ni negociable en ningún refactor futuro.

---

## 6. Bloqueadores históricos ya resueltos

- PATH de Node.js en CMD (Windows)
- Conflictos de peer dependencies en npm
- Reactivación de Supabase
- Discrepancias de variables de entorno entre local y Vercel

## 7. Bloqueadores activos / pendientes técnicos

- **Sentry y Upstash Redis:** instalación pendiente. Bloqueada previamente por el mismo problema de PATH de Node.js en Windows — no se ha reintentado desde que se identificó la causa raíz (usar CMD en vez de PowerShell).
- **PAC (timbrado fiscal CFDI):** no contratado aún. Recomendación: Facturapi o SW Sapien.
- **WhatsApp Business API:** no activa. Recomendación: Twilio o 360dialog. Ya existen **4 plantillas de mensaje** redactadas y listas para enviar a aprobación de Meta (categoría "utility"):
  1. Confirmación de cita
  2. Recordatorio 24 horas antes
  3. Receta lista
  4. Confirmación de pago

---

## 8. UX — estado actual

Score de UX interno: **72/100**. Mejoras identificadas pendientes:
- Tour dentro de la app (in-app tour / onboarding guiado)
- Empty states (estados vacíos) bien diseñados
- Mensajes de error humanizados (actualmente probablemente son errores técnicos crudos)

---

## 9. Documentos de referencia ya generados (contexto de negocio, no técnico, pero útil para el nuevo programador entender el "por qué")

- `MIDOC_Investor_Deck.pptx` — 13 slides, pitch a inversionistas
- `MIDOC_Demo_Doctores.pptx` — 17 slides, deck de ventas a médicos
- `MIDOC_Documentacion_Organizada.zip` — 6 carpetas: finanzas, jurídico, mercadotecnia, producto, programación, operaciones
- `CAC_LTV_MIDOC.md`
- `SOW_Programador_MIDOC.md` — **el scope of work que probablemente se usó para contratarte a ti**
- `Estrategia_vs_Doctoralia_MIDOC.md`
- `Lista_Inversionistas_MIDOC.md`
- `MIDOC_Presupuesto_Arranque.xlsx`
- Modelo financiero a 5 años (Excel, 4 pestañas: Supuestos, Clientes, P&L, Resumen)

---

## 10. Marco interno de gestión ("El Consejo") — 6 agentes funcionales

Es un lente usado por el founder para evaluar el negocio, no un componente de software:

| Agente | Función |
|---|---|
| LOBO | Finanzas / CFO |
| LIC | Legal |
| MERCA | Ventas / Marketing |
| LINDA | Customer Success |
| ARQUI | Tecnología |
| DISEÑO | UX / Producto |

Score general del negocio bajo este marco: **68/100**. Gaps principales identificados: documentos legales no publicados, cero presencia en redes sociales, sin video demo, sin monitoreo (Sentry/Redis pendientes — ver sección 7).

---

## 11. Nota importante sobre estructura de carpetas del repo

Este documento **no incluye el árbol de archivos real del repositorio** porque no fue generado inspeccionando el código directamente — está basado en el historial de decisiones y builds documentado en las conversaciones con el founder. **Primera tarea recomendada para el nuevo programador:** clonar el repo, correr `tree -L 3 -I node_modules` (o equivalente) y añadir el árbol real de estructura a este documento como sección 12, incluyendo dónde viven los 10 módulos, las rutas de API/Server Actions, y el esquema de tablas en Supabase.

---

## 12. Estructura del proyecto (PENDIENTE — completar por el nuevo programador)

```
[Completar tras inspección del repo]
midoc-app/
├── app/                  (rutas Next.js 14 - App Router)
├── components/
├── lib/
│   └── supabase/         (admin client con createClient directo)
├── ...
```
